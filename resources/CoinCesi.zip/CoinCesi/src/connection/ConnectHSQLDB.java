package connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Classe de connexion � la BDD
 * 
 * @author aaubin
 *
 */
public class ConnectHSQLDB                  {

	private static Connection connection;

	public static Connection getConnection() {
		connection = null;
		try {
			Class.forName("org.hsqldb.jdbcDriver");
			connection = DriverManager.getConnection("jdbc:hsqldb:file:C:/Temp/db", "SA", "");
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		return connection;
	}

}
