package connection;

import java.sql.SQLException;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

@WebListener
public class InitializeListener implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        try {
			ConnectHSQLDB.getConnection()
			.createStatement().executeQuery("CREATE TABLE IF NOT EXISTS coin (name varchar(50) NOT NULL,  price INT NOT NULL)");
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        System.out.println("On shutdown web app");
    }

}
