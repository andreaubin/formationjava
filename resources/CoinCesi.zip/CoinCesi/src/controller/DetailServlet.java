package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.impl.CoinDaoImpl;
import model.Coin;

@WebServlet("/detail")
public class DetailServlet extends HttpServlet {
	
	private static final long serialVersionUID = 8799378777510377783L;
	
	private CoinDaoImpl coinDao = new CoinDaoImpl();
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Coin coin = coinDao.getCoinByName(request.getParameter("name"));
		request.setAttribute("coin", coin);
		
		this.getServletContext().getRequestDispatcher("/WEB-INF/detail.jsp").forward(request, response);
	}

}
