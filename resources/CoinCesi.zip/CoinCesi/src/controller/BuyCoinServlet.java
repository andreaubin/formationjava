package controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.impl.CoinDaoImpl;
import model.Buying;
import model.Coin;

@WebServlet("/buyCoin")
public class BuyCoinServlet extends HttpServlet {
	
	private CoinDaoImpl dao = new CoinDaoImpl();

	private static final long serialVersionUID = -2458012001336777110L;

	@SuppressWarnings("unchecked")
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String coinName = request.getParameter("monnaie");
		Coin coin = dao.getCoinByName(coinName);
		
		Integer quantity = Integer.valueOf((String) request.getParameter("quantity"));
		
		HttpSession session = request.getSession();
		Map<String, Buying> map = (Map<String, Buying>) session.getAttribute("panier");
		
		if (map == null) {
			map = new HashMap<>();
			map.put(coin.getName(), new Buying(coin, quantity));
		} else if (map.get(coin.getName()) == null) {
			map.put(coin.getName(), new Buying(coin, quantity));
		} else {
			Buying buying = map.get(coin.getName());
			map.put(coin.getName(), new Buying(coin, buying.getQuantity() + quantity));
		}
		
		session.setAttribute("panier", map);
		
		this.getServletContext().getRequestDispatcher("/WEB-INF/detail.jsp").forward(request, response);
	}
}
