package controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Buying;

/**
 * Servlet implementation class AccountServlet
 */
@WebServlet("/account")
public class AccountServlet extends HttpServlet {

	private static final long serialVersionUID = 6815205148855070372L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@SuppressWarnings("unchecked")
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Map<String, Buying> map = (Map<String, Buying>) request.getSession().getAttribute("panier");
		
		if (map != null) {
			List<Buying> list = map.values().stream()
			.collect(Collectors.toList());
			request.setAttribute("listBuying", list);
			
			Integer total = list.stream().mapToInt(Buying::getTotal).sum();
			request.setAttribute("total", total);
		}
		
		this.getServletContext().getRequestDispatcher("/WEB-INF/account.jsp").forward(request, response);
	}

}
