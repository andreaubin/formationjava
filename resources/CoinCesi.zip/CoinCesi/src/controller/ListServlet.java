package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.impl.CoinDaoImpl;
import model.Coin;

@WebServlet("/list")
public class ListServlet extends HttpServlet {
	
	private static final long serialVersionUID = -8946828595840300917L;
	
	private CoinDaoImpl coinDao = new CoinDaoImpl();
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Coin> list = coinDao.listAllCoin();
		request.setAttribute("listCoin", list);
		
		this.getServletContext().getRequestDispatcher("/WEB-INF/list.jsp").forward(request, response);
	}

}
