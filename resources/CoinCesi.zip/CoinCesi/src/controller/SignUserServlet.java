package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.impl.UserDaoImpl;
import model.User;

@WebServlet("/signUser")
public class SignUserServlet extends HttpServlet {

	private static final long serialVersionUID = 4979708128241576870L;
	
	private UserDaoImpl dao = new UserDaoImpl();
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String login = (String) request.getParameter("login");
		String password = (String) request.getParameter("password");
		if (login != null && password != null) {
			dao.subscribe(new User(login, password));
			
			this.getServletContext().getRequestDispatcher("/list").forward(request, response);
		}
		
		
	}
}
