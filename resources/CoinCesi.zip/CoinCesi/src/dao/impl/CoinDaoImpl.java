package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import connection.ConnectHSQLDB;
import dao.CoinDao;
import model.Coin;

/**
 * Impl�mentation des m�thodes de DAO pour l'objet Coin
 * 
 * @author aaubin
 *
 */
public class CoinDaoImpl implements CoinDao {

	/* (non-Javadoc)
	 * @see dao.CoinDao#listAllCoin()
	 */
	@Override
	public List<Coin> listAllCoin() {
		Connection connection = ConnectHSQLDB.getConnection();
		List<Coin> listCoin = new ArrayList<>();
		ResultSet resultSet = null;
		Statement statement = null;

		try {
			statement = connection.createStatement();
			resultSet = statement.executeQuery("SELECT * FROM COIN");
			while (resultSet.next()) {
				Coin coin = new Coin("111", resultSet.getString("name"), resultSet.getInt("price"));
				listCoin.add(coin);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				resultSet.close();
				statement.close();
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return listCoin;
	}
	
	/* (non-Javadoc)
	 * @see dao.CoinDao#addCoin(model.Coin)
	 */
	@Override
	public void addCoin(Coin coin) {
		Connection connection = ConnectHSQLDB.getConnection();
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = connection.prepareStatement("insert into COIN (name, price) values (?, ?)");
			preparedStatement.setString(1, coin.getName());
			preparedStatement.setInt(2, coin.getPrice());
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (preparedStatement != null) {
					preparedStatement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	/* (non-Javadoc)
	 * @see dao.CoinDao#getCoinByName()
	 */
	@Override
	public Coin getCoinByName(String name) {
		Connection connection = ConnectHSQLDB.getConnection();
		Coin coin = null;
		ResultSet rs = null;
		PreparedStatement preparedStatement = null;

		try {
			preparedStatement = connection.prepareStatement("SELECT NAME, PRICE FROM COIN where NAME = ?");
			preparedStatement.setString(1, name);
			
			rs = preparedStatement.executeQuery();

			while (rs.next()) {
				coin = new Coin(null, rs.getString("NAME"), rs.getInt("PRICE"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				preparedStatement.close();
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return coin;
	}

}
