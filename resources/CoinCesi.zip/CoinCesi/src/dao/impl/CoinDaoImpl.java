package dao.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import connection.ConnectHSQLDB;
import dao.CoinDao;
import model.Coin;

/**
 * Impl�mentation des m�thodes de DAO pour l'objet Coin
 * 
 * @author aaubin
 *
 */
public class CoinDaoImpl implements CoinDao {

	/* (non-Javadoc)
	 * @see dao.CoinDao#listAllCoin()
	 */
	@Override
	public List<Coin> listAllCoin() {
		Connection connection = ConnectHSQLDB.getConnection();
		List<Coin> listCoin = new ArrayList<>();
		ResultSet resultSet = null;
		Statement statement = null;

		try {
			statement = connection.createStatement();
			resultSet = statement.executeQuery("SELECT * FROM COIN");
			while (resultSet.next()) {
				Coin coin = new Coin("111", resultSet.getString("name"), resultSet.getInt("price"));
				listCoin.add(coin);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				resultSet.close();
				statement.close();
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return listCoin;
	}

}
