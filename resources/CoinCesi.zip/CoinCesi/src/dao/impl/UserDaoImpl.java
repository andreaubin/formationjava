package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import connection.ConnectHSQLDB;
import dao.UserDao;
import model.User;

public class UserDaoImpl implements UserDao {

	@Override
	public void subscribe(User user) {
		Connection connection = ConnectHSQLDB.getConnection();
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = connection.prepareStatement("insert into USER (login, password) values (?, ?)");
			preparedStatement.setString(1, user.getLogin());
			preparedStatement.setString(2, user.getPassword());
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (preparedStatement != null) {
					preparedStatement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}

	@Override
	public User getUser(String login, String password) {
		Connection connection = ConnectHSQLDB.getConnection();
		User user = null;
		ResultSet rs = null;
		PreparedStatement preparedStatement = null;

		try {
			preparedStatement = connection.prepareStatement("SELECT LOGIN, PASSWORD FROM USER where LOGIN = ? and PASSWORD = ?");
			preparedStatement.setString(1, login);
			preparedStatement.setString(2, password);
			
			rs = preparedStatement.executeQuery();

			while (rs.next()) {
				user = new User(rs.getString("LOGIN"), rs.getString("PASSWORD"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				preparedStatement.close();
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return user;
	}

}
