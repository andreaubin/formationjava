package dao;

import model.User;

public interface UserDao {
	
	void subscribe(User user);
	
	User getUser(String login, String password);

}
