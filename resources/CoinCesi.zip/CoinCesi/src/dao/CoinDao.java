package dao;

import java.util.List;

import model.Coin;

public interface CoinDao {
	
	List<Coin> listAllCoin();
	
	Coin getCoinByName(String name);
	
	void addCoin(Coin coin);
	
}
