package com.test.xml;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		BeanFactory beanFactory = (BeanFactory) new FileSystemXmlApplicationContext("src/main/webapp/WEB-INF/beans-conf.xml");
		
		Voiture voiture = (Voiture) beanFactory.getBean("maVoiture");
		
		voiture.rouler();

	}

}
