package com.test.xml;

public class Voiture {

	private String marque;

	private String modele;

	private Personne conducteur;

	public void rouler() {
		System.out.println(conducteur.getPrenom() + " " + conducteur.getNom() + " conduit dans sa " + this.marque + " "
				+ this.modele + " et c'est cool");
	}

	public String getMarque() {
		return marque;
	}

	public void setMarque(String marque) {
		this.marque = marque;
	}

	public String getModele() {
		return modele;
	}

	public void setModele(String modele) {
		this.modele = modele;
	}

	public Personne getConducteur() {
		return conducteur;
	}

	public void setConducteur(Personne conducteur) {
		this.conducteur = conducteur;
	}

}
