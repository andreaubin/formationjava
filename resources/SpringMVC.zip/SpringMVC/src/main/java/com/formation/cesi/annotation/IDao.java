package com.formation.cesi.annotation;

public interface IDao {
	
	String loadValue();

}
