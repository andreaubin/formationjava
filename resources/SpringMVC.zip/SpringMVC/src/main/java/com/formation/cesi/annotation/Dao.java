package com.formation.cesi.annotation;

import org.springframework.stereotype.Repository;

@Repository
public class Dao implements IDao {

	public String loadValue() {
		return "Je suis la valeur retourn�e par l'impl�mentation de base";
	}

}
