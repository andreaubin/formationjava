package com.formation.cesi;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.formation.cesi.annotation.IDao;

@Controller
public class GoodByeController {
	
	@Autowired
	private IDao dao;
	
	@RequestMapping(value="/aurevoir", method = RequestMethod.GET)
    public String afficherAuRevoirViaRequest(final ModelMap model, 
                @RequestParam(value="personne") final String personne) {

        model.addAttribute("personne", personne);
        return "aurevoir";
    }
	
	@RequestMapping(value="/aurevoir/{personne}", method = RequestMethod.GET)
    public String afficherAuRevoirViaPath(final ModelMap model, 
                @PathVariable(value="personne") final String personne) {

        model.addAttribute("personne", personne);
        return "aurevoir";
    }
	
//	@RequestMapping(value="/test", method = RequestMethod.GET)
//    public String testDao(final ModelMap model) {
//
//        model.addAttribute("phraseDao", dao.loadValue());
//        return "test";
//    }

}
