package com.formation.cesi.annotation;

public class HibernateDao {

}
