package com.formation.cesi.service;

import java.util.List;

import com.formation.cesi.model.Coin;

public interface CoinService {
	
	List<Coin> listAllCoin();

	Coin getCoinByName(String name);

	void addCoin(Coin coin);
}
