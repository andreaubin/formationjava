package com.formation.cesi.utils;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class LoggingAspect {
	
	@Before("execution(* com.formation.cesi..*.*(..))")
	public void logBefore(JoinPoint joinPoint) {
		System.out.println("Start -> Method name : " + joinPoint.getSignature().getName());
	}
	
	@After("execution(* com.formation.cesi.controller.*.*(..))")
	public void logAfter(JoinPoint joinPoint) {
		System.out.println("End -> Methode name : " + joinPoint.getSignature().getDeclaringTypeName() + "."  + joinPoint.getSignature().getName());
	}

}
