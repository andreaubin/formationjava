package com.formation.cesi.model;

public class Buying {
	
	public Buying(Coin coin, Integer quantity) {
		super();
		this.coin = coin;
		this.quantity = quantity;
	}

	private Coin coin;
	
	private Integer quantity;

	public Coin getCoin() {
		return coin;
	}

	public void setCoin(Coin coin) {
		this.coin = coin;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	
	public Integer getTotal() {
		return quantity * coin.getPrice();
	}
	
}
