package com.formation.cesi.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="COIN")
public class Coin {
	
	public Coin() {
		// empty constructor
	}
	
	public Coin(String name, Integer price) {
		super();
		this.name = name;
		this.price = price;
	}
	
	@Id
	private String name;
	
	private Integer price;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	
}
