package com.formation.cesi.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.formation.cesi.form.CreateCoinForm;
import com.formation.cesi.model.Coin;
import com.formation.cesi.service.CoinService;
import com.formation.cesi.utils.IConstants;

@Controller
public class CoinController {

	@Autowired
	private CoinService coinService;

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public String loadList(final ModelMap model) {
		List<Coin> list = coinService.listAllCoin();
		model.addAttribute("listCoin", list);

		return IConstants.Url.LIST;
	}

	@RequestMapping(value = "/list/{name}", method = RequestMethod.GET)
	public String loadCoin(final ModelMap model, @PathVariable(value = "name") final String name) {
		Coin coin = coinService.getCoinByName(name);
		model.addAttribute("coin", coin);

		return IConstants.Url.DETAIL;
	}
	
	@RequestMapping(value="/add", method = RequestMethod.POST)
    public String creer(@Valid @ModelAttribute(value="coinForm") final CreateCoinForm coinForm, 
            final BindingResult bindingResult, final ModelMap model) {

        if (!bindingResult.hasErrors()) {
            Coin coin = new Coin(coinForm.getName(), Integer.valueOf(coinForm.getPrice()));
            coinService.addCoin(coin);
        }
        return loadList(model);
    }

}
