package com.formation.cesi.dao;

import java.util.List;

import com.formation.cesi.model.Coin;

public interface CoinDao {
	
	List<Coin> listAllCoin();
	
	Coin getCoinByName(String name);
	
	void addCoin(Coin coin);
	
}
