package com.formation.cesi.utils;

public interface IConstants {

	public interface Url {
		
		public static final String LIST = "list";
		
		public static final String DETAIL = "detail";
		
	}

}
