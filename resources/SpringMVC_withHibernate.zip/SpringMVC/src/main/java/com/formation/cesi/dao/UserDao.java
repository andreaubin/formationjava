package com.formation.cesi.dao;

import com.formation.cesi.model.User;

public interface UserDao {
	
	void subscribe(User user);
	
	User getUser(String login, String password);

}
