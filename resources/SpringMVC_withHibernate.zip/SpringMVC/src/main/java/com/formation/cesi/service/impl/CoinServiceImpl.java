package com.formation.cesi.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.formation.cesi.dao.CoinDao;
import com.formation.cesi.model.Coin;
import com.formation.cesi.service.CoinService;

@Service
public class CoinServiceImpl implements CoinService {
	
	@Autowired
	private CoinDao coinDao;

	@Override
	public List<Coin> listAllCoin() {
		return coinDao.listAllCoin();
	}

	@Override
	public Coin getCoinByName(String name) {
		return coinDao.getCoinByName(name);
	}

	@Override
	public void addCoin(Coin coin) {
		coinDao.addCoin(coin);
	}

}
