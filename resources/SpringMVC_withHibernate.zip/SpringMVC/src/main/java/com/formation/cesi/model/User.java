package com.formation.cesi.model;

import java.io.Serializable;

public class User implements Serializable {
	
	private static final long serialVersionUID = 5877015601886252145L;

	private String login;
	
	private String password;
	
	private boolean isConnected;
	
	public User(String login, String password) {
		super();
		this.login = login;
		this.password = password;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isConnected() {
		return isConnected;
	}

	public void setConnected(boolean isConnected) {
		this.isConnected = isConnected;
	}
	
}
