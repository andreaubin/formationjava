package com.formation.cesi.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.formation.cesi.dao.CoinDao;
import com.formation.cesi.model.Coin;

/**
 * Impl�mentation des m�thodes de DAO pour l'objet Coin
 * 
 * @author aaubin
 *
 */
@Repository
public class CoinDaoImpl implements CoinDao {
	
	@PersistenceContext
    private EntityManager entityManager;
	
	/* (non-Javadoc)
	 * @see com.formation.cesi.dao.CoinDao#listAllCoin()
	 */
	@Override
	public List<Coin> listAllCoin() {
		Query query = entityManager.createQuery("from Coin");
		@SuppressWarnings("unchecked")
		List<Coin> listCoin = (List<Coin>) query.getResultList();
		return listCoin;
		
//		final CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
//
//        final CriteriaQuery<Coin> criteriaQuery = criteriaBuilder.createQuery(Coin.class);
//        final Root<Coin> root = criteriaQuery.from(Coin.class);
//        criteriaQuery.select(root);
//        final TypedQuery<Coin> typedQuery = entityManager.createQuery(criteriaQuery);
//
//        return typedQuery.getResultList();
	}
	
	/* (non-Javadoc)
	 * @see com.formation.cesi.dao.CoinDao#getCoinByName(java.lang.String)
	 */
	@Override
	public Coin getCoinByName(String name) {
		Query query = entityManager.createQuery("from Coin where name = :name ");
		query.setParameter("name", name);
		Coin coin = (Coin) query.getSingleResult();
		return coin;
	}

	/* (non-Javadoc)
	 * @see com.formation.cesi.dao.CoinDao#addCoin(com.formation.cesi.model.Coin)
	 */
	@Override
	public void addCoin(Coin coin) {
		entityManager.persist(coin);
	}

}
